# -*- coding: utf-8 -*-
import sys
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import butter, freqz, square

# 1. Setup parameters and generate square wave
# f_square: Square wave frequency (10 kHz)
# sampling_rate: Sampling rate (1 MHz), must be much higher than the signal frequency
# t: Time vector, set to display 5 cycles
f_square = 10000
sampling_rate = 1000000

# Add a check to prevent ZeroDivisionError
if f_square <= 0 or sampling_rate <= 0:
    print("Error: f_square and sampling_rate must be positive non-zero numbers.")
    sys.exit(1) # Exit the script if the check fails

# --- FIX for Python 2 Integer Division ---
# In Python 2, dividing integers truncates the result (e.g., 1/1000 becomes 0).
# Using 5.0 and 1.0 forces floating-point division, ensuring compatibility.
stop_time = 5.0 / f_square
step_size = 1.0 / sampling_rate
t = np.arange(0, stop_time, step_size)
# --- End of FIX ---

square_wave = square(2 * np.pi * f_square * t)

# 2. Build a second-order high-pass filter
# cutoff_freq: Cutoff frequency (20 kHz), set higher than the fundamental frequency
# order: Filter order
cutoff_freq = 20000
nyquist_freq = 0.5 * sampling_rate
order = 2
# Normalize the cutoff frequency
normal_cutoff = cutoff_freq / nyquist_freq
# Design the Butterworth filter using 'butter'
# b, a are the numerator and denominator polynomial coefficients of the filter
b, a = butter(order, normal_cutoff, btype='high', analog=False)
# Calculate the frequency response of the filter
w, h = freqz(b, a, worN=8000)

# 3. Calculate the spectrum of the square wave
# n_points: Total number of data points in the signal
# freq_domain: Result of the Fast Fourier Transform (FFT) on the time-domain signal
# freqs: Frequency bins corresponding to the FFT result
n_points = len(square_wave)
freq_domain = np.fft.fft(square_wave)
# --- FIX for Python 2 Integer Division ---
# The second argument to fftfreq is the sample spacing (1 / sampling_rate).
# In Python 2, this resulted in 0. Using 1.0 forces float division.
freqs = np.fft.fftfreq(n_points, 1.0/sampling_rate)
# --- End of FIX ---

# 4. Apply the filter in the frequency domain
# Since the frequency points from freqz and fft may not align perfectly,
# we use linear interpolation (interp) to get the filter gain at each signal frequency point.
filter_response = np.interp(np.abs(freqs), (w / (2 * np.pi)) * sampling_rate, np.abs(h))
# Multiply the signal spectrum by the filter response point-by-point
filtered_freq_domain = freq_domain * filter_response

# 5. Inverse Fourier Transform
# Perform an Inverse Fast Fourier Transform (IFFT) on the filtered frequency-domain signal
# .real is used to extract the real part of the result, as minor imaginary errors can occur
filtered_time_domain = np.fft.ifft(filtered_freq_domain)

# 6. Plotting
# Create a figure to hold multiple subplots
plt.figure(figsize=(15, 12))

# Plot 1: Original Square Wave (Time Domain)
plt.subplot(3, 2, 1)
plt.plot(t, square_wave)
plt.title('Original Square Wave (Time Domain)')
plt.xlabel('Time [s]')
plt.ylabel('Amplitude')
plt.grid(True)
plt.xlim(0, 2.0 / f_square) # Limit x-axis to show two cycles clearly

# Plot 2: Square Wave Spectrum
# Display only the positive frequency part (up to the Nyquist frequency)
plt.subplot(3, 2, 2)
plt.plot(freqs[:n_points // 2], np.abs(freq_domain)[:n_points // 2])
plt.title('Square Wave Spectrum')
plt.xlabel('Frequency [Hz]')
plt.ylabel('Magnitude')
plt.grid(True)
plt.xlim(0, 100000) # Limit x-axis to observe the main harmonics

# Plot 3: High-pass Filter Frequency Response
plt.subplot(3, 2, 3)
plt.plot((w / (2 * np.pi)) * sampling_rate, np.abs(h), 'b')
plt.title('2nd-Order High-Pass Filter Frequency Response')
plt.xlabel('Frequency [Hz]')
plt.ylabel('Gain')
plt.grid(True)
# Use the .format() method for backward compatibility with older Python versions
plt.axvline(cutoff_freq, color='red', linestyle='--', label='Cutoff Frequency: {} Hz'.format(cutoff_freq))
plt.legend()
plt.xlim(0, 100000)

# Plot 4: Filtered Spectrum
plt.subplot(3, 2, 4)
plt.plot(freqs[:n_points // 2], np.abs(filtered_freq_domain)[:n_points // 2])
plt.title('Filtered Spectrum')
plt.xlabel('Frequency [Hz]')
plt.ylabel('Magnitude')
plt.grid(True)
plt.xlim(0, 100000)

# Plot 5: Filtered Signal (Time Domain)
plt.subplot(3, 2, 5)
plt.plot(t, filtered_time_domain.real)
plt.title('Filtered Signal (Time Domain)')
plt.xlabel('Time [s]')
plt.ylabel('Amplitude')
plt.grid(True)
plt.xlim(0, 2.0 / f_square)

# Adjust subplot layout to prevent titles and labels from overlapping
# The 'rect' parameter adds padding: [left, bottom, right, top]
plt.tight_layout(rect=[0, 0.03, 1, 0.97])
# Display the plot
plt.show()
