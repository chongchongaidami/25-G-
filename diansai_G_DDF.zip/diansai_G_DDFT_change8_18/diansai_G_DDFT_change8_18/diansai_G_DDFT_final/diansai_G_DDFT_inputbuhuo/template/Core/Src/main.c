/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ad9959.h"
#include "stdio.h"
#include <stdarg.h> // for va_list
#include "arm_math.h"
#include <stdlib.h> // ????????? qsort ??
#include <string.h> // ????????? memcpy ??
#include "OLED.h" 
#include <math.h>
#include <complex.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum {
    STATE_IDLE,
    STATE_BASIC, // 主程序的基础模式状态
    STATE_SWEEPING,
    STATE_ANALYZING,
    STATE_DISPLAY_RESULTS,
    STATE_SIMULATING
} AppState;
#define KEYPAD_BUFFER_SIZE 10
#define KEYPAD_FRAME_HEAD 0xFF
#define KEYPAD_FRAME_TAIL 0xEE
#define KEY_CONFIRM 0x10  // 确认键
#define KEY_ZERO 0x0A     // 0键
#define KEY_BACKSPACE 0x0E//退出 
volatile uint8_t g_keypad_uart_byte;
typedef enum {
    RX_STATE_WAIT_FOR_HEAD,
    RX_STATE_WAIT_FOR_DATA,
    RX_STATE_WAIT_FOR_TAIL
} KeypadRxState;
// 菜单状态枚举
typedef enum {
    MENU_MAIN,
    MENU_SET_FREQ,
    MENU_SET_OUTPUT,
    MENU_RUNNING
} MenuState;
// Enum for the determined filter type 
typedef enum {
    FILTER_TYPE_UNKNOWN,
    FILTER_TYPE_LOW_PASS,
    FILTER_TYPE_HIGH_PASS,
    FILTER_TYPE_BAND_PASS,
    FILTER_TYPE_BAND_STOP
} FilterType;
// 基础要求变量
MenuState g_menu_state = MENU_MAIN;
uint8_t g_keypad_rx_buffer[3];
uint8_t g_keypad_rx_index = 0;
volatile uint8_t g_keypad_data_ready = 0;
uint8_t g_last_key_pressed = 0;
#define DDS_VPP_TO_AMP_SCALE 316.0f
char g_input_buffer[KEYPAD_BUFFER_SIZE];
uint8_t g_input_index = 0;

// 基础要求设置值
uint32_t g_target_freq_hz = 1000;        // 目标频率 (Hz)
uint32_t g_target_output_mv = 2000;      // 目标输出电压 (mV)
uint8_t g_basic_mode_active = 0;         // 基础模式激活标志
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// 新增：基础模式下的幅度设置模式
typedef enum {
    AMP_MODE_DIRECT,       // 直接设置DDS输出电压 Vpp
    AMP_MODE_MODEL_OUTPUT  // 设置已知模型电路的目标输出电压 Vpp
} BasicAmpMode;
BasicAmpMode g_basic_amp_mode = AMP_MODE_MODEL_OUTPUT;
#define ADC_VREF_V 3.3f
// PI 的定义，如果您的 math.h 没有定义 M_PI
#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif
// ADC分辨率 (位数)。例如：12位ADC为 2^12 = 4096
// !!! 重要：请修改为您的ADC的实际分辨率 !!!
#define ADC_RESOLUTION 1024
#define DAC_RESOLUTION 4096 // 用于12位的DAC
#define ADC_SAMPLES_PER_HALF_BUFFER 840
#define ADC_TOTAL_BUFFER_SIZE       (ADC_SAMPLES_PER_HALF_BUFFER * 2)
#define NUM_SAMPLES ADC_SAMPLES_PER_HALF_BUFFER
#define SWEEP_START_FREQ_HZ 200
#define SWEEP_END_FREQ_HZ   500000
#define SWEEP_STEP_FREQ_HZ  200
#define NUM_SWEEP_STEPS     ((SWEEP_END_FREQ_HZ - SWEEP_START_FREQ_HZ) / SWEEP_STEP_FREQ_HZ + 1)
#define SETTLE_TIME_MS      20
// ??????????
#define FLAT_TOP_COHERENT_GAIN (0.21557895f)
#define HANNING_COHERENT_GAIN  (0.5f)
#define MAX_SIM_COMPONENTS 50
#define RELAY_STATE_LEARN    GPIO_PIN_RESET // ?????????ADC2???
#define RELAY_STATE_SIMULATE GPIO_PIN_SET   // ??????ADC2???
/* --- NEW: Defines for Basic Requirements from teammate's code --- */
// IMPORTANT: This scale factor needs to be calibrated for your hardware.
// It converts the desired Vpp output to the required AD9959 amplitude setting.
// Formula: Scale = (AD9959_Max_Amp_Value / DDS_Max_Vpp_Output)
// Example: If 1023 setting gives 3.0Vpp, Scale = 1023 / 3.0 = 341
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

volatile uint8_t g_dac_data_needs_processing = 0;
uint16_t g_adc2_processing_buffer_A[ADC_SAMPLES_PER_HALF_BUFFER];
uint16_t g_adc2_processing_buffer_B[ADC_SAMPLES_PER_HALF_BUFFER];
uint16_t show_buffer[ADC_SAMPLES_PER_HALF_BUFFER];
volatile uint16_t* g_p_adc2_buffer_to_process = NULL;

volatile int g_num_significant_freqs = 0;

// --- Variables for Basic Requirements ---
uint32_t g_basic_freq_hz = 1000;      // Default frequency 1kHz
uint32_t g_basic_output_mv = 2000;    // Default output 2.0V (2000mV)
// --- ??: ????????DMA??? ---
volatile uint16_t g_adc1_dma_buffer[ADC_TOTAL_BUFFER_SIZE];
volatile uint16_t g_adc2_dma_buffer[ADC_TOTAL_BUFFER_SIZE];
volatile uint16_t g_dac_output_buffer[ADC_TOTAL_BUFFER_SIZE]; 
// --- ??: ?????????????? ---
uint16_t g_adc1_processing_buffer[ADC_SAMPLES_PER_HALF_BUFFER];
uint16_t g_adc2_processing_buffer[ADC_SAMPLES_PER_HALF_BUFFER];

// ??????
volatile uint8_t g_adc1_data_ready = 0;
volatile uint8_t g_adc2_data_ready = 0;

volatile float g_current_sampling_simulation = 1000000.0f; 
volatile float    g_measured_freq = 0.0f;
volatile float g_current_signal_rate=1.0f;
volatile uint8_t stop_flag = 0;
volatile AppState g_app_state = STATE_IDLE;
FilterType g_filter_type = FILTER_TYPE_UNKNOWN;
volatile uint8_t dac_half_flag=0;
volatile uint8_t dac_full_flag=0;
volatile uint8_t stable_flag=0;
// ???????
float g_H_magnitude[NUM_SWEEP_STEPS]; // �洢H(w)�ķ���
float g_H_phase[NUM_SWEEP_STEPS];     // �洢H(w)����λ
uint32_t g_sweep_current_step = 0;
uint32_t g_current_freq_sweep = SWEEP_START_FREQ_HZ;
float sampling_frequency_sweep;
float multiplier ;
volatile int g_sampling_multiplier = 20; // 新增：用于存储当前的采样倍数
// DMA输入捕获缓冲区大小，可以根据需要调整
#define TIMER4_TICK_FREQ_HZ 500000.0f 
#define CAPTURE_BUFFER_SIZE   200 
uint32_t g_calc_half_buffer[CAPTURE_BUFFER_SIZE / 2];
uint32_t g_calc_full_buffer[CAPTURE_BUFFER_SIZE / 2];
uint32_t calc_buffer[CAPTURE_BUFFER_SIZE / 2];
// 用于存储DMA传输的定时器捕获值
volatile uint32_t g_tim_capture_buffer[CAPTURE_BUFFER_SIZE];
// --- 新增：用于通知主循环的标志位 ---
volatile uint8_t g_capture_buffer_half_ready = 0; // 缓冲区前半部分数据就绪标志
volatile uint8_t g_capture_buffer_full_ready = 0; // 缓冲区后半部分数据就绪标志
static float last_phase_diff = 0.0f; // Used to store the phase difference of the previous frequency step


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void Start_Sweep_And_Analysis(void);
// --- ??: ?????????????????? ---
float Get_Signal_Amplitude(const uint16_t* processing_buffer);
void Analyze_Filter_Response(void);
void Display_Results(void);
HAL_StatusTypeDef Safely_Update_Sampling_Frequency(uint32_t new_sampling_freq_hz);

void Get_Signal_Accurate_Amplitude_And_Phase(const uint16_t* processing_buffer,
                                             float target_frequency_hz,
                                             float current_sampling_freq_hz,
                                             float* p_amplitude_v,
                                             float* p_phase_rad);
void Find_Significant_Frequencies_FFT(const uint16_t* adc_buffer, float* found_freqs_hz, int* num_freqs_found);
void Process_Buffer_DFT_SIM(const uint16_t* adc_src,
                           volatile uint16_t* dac_dest,
                           float signal_base_freq_hz,
                           float sampling_freq_hz);																 
void Start_Simulation_Mode(void);
void Stop_Simulation_Mode(void);
void Process_And_Fill_DAC_Buffer(const uint16_t* adc_src,volatile uint16_t* dac_dest, uint32_t count); 
/* --- NEW: Function from teammate's code for Basic Requirements --- */
double calculate_known_filter_gain(double f);
void update_basic_control_display(void);
void Process_Keypad_Input(void);
void Handle_Menu_Navigation(uint8_t key);
void Enter_Basic_Mode(void);
void Update_Display(void);
double Calculate_H_Magnitude(double freq_hz);
void Calculate_Required_Output(void);
void Start_Basic_Mode(void);
void Update_DDS_Output(void);
void Stop_Basic_Mode(void);
void Process_Capture_Buffer(volatile uint32_t* buffer, uint16_t len);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_DAC_Init();
  MX_TIM4_Init();
  MX_I2C2_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
	Init_AD9959(); 
	OLED_init(); 
	//OLED_LOGO();
	HAL_Delay(500);
	Write_frequence(0,1000);
	Write_Amplitude(3, 0);
	Write_frequence(3,100000);
	OLED_operate_gram(PEN_CLEAR);
	OLED_show_string(0, 0, (uint8_t *)"--- STATUS ---");
	OLED_show_string(1, 0, (uint8_t *)"Mode: IDLE");
	OLED_show_string(2, 0, (uint8_t *)"Press a key...");
	OLED_refresh_gram();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
     switch (g_app_state) {
        case STATE_IDLE:
					if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET) { // 假设PA0是基础模式按键
                HAL_Delay(20);
                if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET) {
                    Enter_Basic_Mode();
                }
            }
            if (HAL_GPIO_ReadPin(LEARN_KEY_GPIO_Port, LEARN_KEY_Pin) == GPIO_PIN_RESET) {
                HAL_Delay(20);
                if (HAL_GPIO_ReadPin(LEARN_KEY_GPIO_Port, LEARN_KEY_Pin) == GPIO_PIN_RESET) {
                    Start_Sweep_And_Analysis();
                }
            }
            if (HAL_GPIO_ReadPin(SIM_KEY_GPIO_Port, SIM_KEY_Pin) == GPIO_PIN_RESET) {
                HAL_Delay(20);
                if (HAL_GPIO_ReadPin(SIM_KEY_GPIO_Port, SIM_KEY_Pin) == GPIO_PIN_RESET) {
                    Start_Simulation_Mode();
                }
            }
            break;
        case STATE_BASIC:
            // 处理基础模式的逻辑
            Process_Keypad_Input();
            if (HAL_GPIO_ReadPin(LEARN_KEY_GPIO_Port, LEARN_KEY_Pin) == GPIO_PIN_RESET) {
              HAL_Delay(20);
              if (HAL_GPIO_ReadPin(LEARN_KEY_GPIO_Port, LEARN_KEY_Pin) == GPIO_PIN_RESET) {
                Start_Sweep_And_Analysis();
             }
           }
    if (HAL_GPIO_ReadPin(SIM_KEY_GPIO_Port, SIM_KEY_Pin) == GPIO_PIN_RESET) {
        HAL_Delay(20);
        if (HAL_GPIO_ReadPin(SIM_KEY_GPIO_Port, SIM_KEY_Pin) == GPIO_PIN_RESET) {
            Start_Simulation_Mode();
        }
    }
            break;
        case STATE_SWEEPING:
            // 等待ADC数据就绪
            if (g_adc1_data_ready==1 && g_adc2_data_ready==1 && stable_flag == 2) {
                g_adc1_data_ready = 0;
                g_adc2_data_ready = 0;

                float input_amp = 0.0f, input_phase = 0.0f;
                float output_amp = 0.0f, output_phase = 0.0f;

                Get_Signal_Accurate_Amplitude_And_Phase(g_adc1_processing_buffer, g_current_freq_sweep, sampling_frequency_sweep, &input_amp, &input_phase);
                Get_Signal_Accurate_Amplitude_And_Phase(g_adc2_processing_buffer, g_current_freq_sweep, sampling_frequency_sweep, &output_amp, &output_phase);

                // 计算并存储 H(w)
                if (input_amp > 0.01f && (output_amp / input_amp < 10.0f)) { // 避免除以零和无效增益
                    g_H_magnitude[g_sweep_current_step] = 2*output_amp / input_amp;
                } else {
                    g_H_magnitude[g_sweep_current_step] = 0.0f;
                }

                // --- KEY FIX: Phase Unwrapping ---
                float phase_diff = output_phase - input_phase;
                
                // For the first frequency point, initialize last_phase_diff
                if (g_sweep_current_step == 0) {
                    // Normalize the first phase difference to the range (-PI, PI]
                    while (phase_diff > M_PI)  phase_diff -= 2.0f * M_PI;
                    while (phase_diff <= -M_PI) phase_diff += 2.0f * M_PI;
                } else {
                    // Starting from the second point, perform phase unwrapping
                    while ((phase_diff - last_phase_diff) > M_PI) {
                        phase_diff -= 2.0f * M_PI;
                    }
                    while ((phase_diff - last_phase_diff) < -M_PI) {
                        phase_diff += 2.0f * M_PI;
                    }
                }
                
                last_phase_diff = phase_diff; // Update the last phase value
                g_H_phase[g_sweep_current_step] = phase_diff; // Store the unwrapped phase
                // --- END OF FIX ---
                //if(g_sweep_current_step==99)
								//{
								//	g_sweep_current_step=99;
								//}
                g_sweep_current_step++;
                if (g_sweep_current_step < NUM_SWEEP_STEPS) {
                    g_current_freq_sweep += SWEEP_STEP_FREQ_HZ;
                    Write_Amplitude(3, 0);
                    HAL_ADC_Stop_DMA(&hadc1);
                    HAL_ADC_Stop_DMA(&hadc2);
                    Write_frequence(0, g_current_freq_sweep);
                     
                    if(g_current_freq_sweep < 80600){
                        sampling_frequency_sweep = g_current_freq_sweep * 15;
                    } else if(g_current_freq_sweep < 140600){
                        sampling_frequency_sweep = g_current_freq_sweep * 8;
                    } else if(g_current_freq_sweep < 300600){
                        sampling_frequency_sweep = g_current_freq_sweep * 4;
                    } else {
                        sampling_frequency_sweep = g_current_freq_sweep * 3;
                    }

                    if (HAL_ADC_Start_DMA(&hadc1, (uint32_t*)g_adc1_dma_buffer, ADC_TOTAL_BUFFER_SIZE) != HAL_OK) {
                        Error_Handler();
                    }
                    if (HAL_ADC_Start_DMA(&hadc2, (uint32_t*)g_adc2_dma_buffer, ADC_TOTAL_BUFFER_SIZE) != HAL_OK) {
                        Error_Handler();
                    }
                    Write_frequence(3, sampling_frequency_sweep);
                    Write_Amplitude(3, 1000);
                    HAL_Delay(SETTLE_TIME_MS); // 等待信号稳定
										g_adc1_data_ready = 0;
                    g_adc2_data_ready = 0;
										stable_flag=0;
                } else {
                    Write_Amplitude(3, 0);
                    HAL_ADC_Stop_DMA(&hadc1);
                    HAL_ADC_Stop_DMA(&hadc2);
                    g_app_state = STATE_ANALYZING;
                }
            }
            break;

        case STATE_ANALYZING:
            Analyze_Filter_Response();
            g_app_state = STATE_DISPLAY_RESULTS;
            break;

        case STATE_DISPLAY_RESULTS:
            Display_Results(); // 显示一次结果
            // 等待用户按下 SIM 键开始仿真
            if (HAL_GPIO_ReadPin(SIM_KEY_GPIO_Port, SIM_KEY_Pin) == GPIO_PIN_RESET) {
                HAL_Delay(20);
                if (HAL_GPIO_ReadPin(SIM_KEY_GPIO_Port, SIM_KEY_Pin) == GPIO_PIN_RESET) {
                    Start_Simulation_Mode();
                }
            }
            break;

        case STATE_SIMULATING:
            if(dac_half_flag==1)
			         {
				          Process_Buffer_DFT_SIM(
                     (const uint16_t*)&g_adc2_processing_buffer,
                     &g_dac_output_buffer[0],
								     g_current_signal_rate,         
                     g_current_sampling_simulation
                );
								    dac_half_flag=0;
			         }

            if(dac_full_flag==1)
			        {
				         Process_Buffer_DFT_SIM(
                    (const uint16_t*)g_adc2_processing_buffer,
                    &g_dac_output_buffer[ADC_SAMPLES_PER_HALF_BUFFER],
                    g_current_signal_rate,
                    g_current_sampling_simulation
                 );
								 dac_full_flag=0;
			         }
							
				        if (g_capture_buffer_half_ready || g_capture_buffer_full_ready) {
                    if (g_capture_buffer_half_ready) {
                        g_capture_buffer_half_ready = 0;
                        Process_Capture_Buffer(g_calc_half_buffer, CAPTURE_BUFFER_SIZE / 2);
                    }
										if (g_capture_buffer_full_ready){ 
                        g_capture_buffer_full_ready = 0;
                        Process_Capture_Buffer(g_calc_full_buffer, CAPTURE_BUFFER_SIZE / 2);
                    }

                    float multiplier_float = g_measured_freq / 200.0f;
                    float rounded_multiplier = roundf(multiplier_float);
                    uint32_t new_signal_rate = (uint32_t)(rounded_multiplier * 200);

                    if (new_signal_rate >= 1000 && g_current_signal_rate != new_signal_rate) {
                        g_current_signal_rate = new_signal_rate;

                        // 根据新的信号频率，确定并存储采样倍数
                        if (g_current_signal_rate < 5600) {
                            g_sampling_multiplier = 120;
                        } else if (g_current_signal_rate < 11600) {
                            g_sampling_multiplier = 60;
                        } else if (g_current_signal_rate < 30600) {
                            g_sampling_multiplier = 30;
                        } else {
                            g_sampling_multiplier = 24;
                        }
                        
                        // 使用新的倍数计算采样频率
                        g_current_sampling_simulation = g_current_signal_rate * g_sampling_multiplier;
                        Write_frequence(3, g_current_sampling_simulation);
                    }
                }
        if (HAL_GPIO_ReadPin(LEARN_KEY_GPIO_Port, LEARN_KEY_Pin) == GPIO_PIN_RESET) {
                HAL_Delay(20);
                if (HAL_GPIO_ReadPin(LEARN_KEY_GPIO_Port, LEARN_KEY_Pin) == GPIO_PIN_RESET) {
                    Start_Sweep_And_Analysis();
                }
            }
            if (HAL_GPIO_ReadPin(LEARN_KEY_GPIO_Port, IDLE_KEY_Pin) == GPIO_PIN_RESET) {
                HAL_Delay(20);
                if (HAL_GPIO_ReadPin(LEARN_KEY_GPIO_Port, IDLE_KEY_Pin) == GPIO_PIN_RESET) {
                    Stop_Simulation_Mode();
                    // 返回空闲状态，让用户选择下一步操作
                    g_app_state = STATE_IDLE; 
                }
            }
            break;
					}
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/**
 * @brief 进入基础要求模式。
 * @note  此函数现在也会启动键盘的UART接收器。
 */
void Enter_Basic_Mode(void) {
    g_app_state = STATE_BASIC;
    g_menu_state = MENU_MAIN;
    g_basic_mode_active = 0; // 初始状态为未运行
    memset(g_input_buffer, 0, sizeof(g_input_buffer));
    g_input_index = 0;

    // --- 启动用于键盘的UART接收中断 ---
    // 这使得键盘仅在基础模式下启用。
    if (HAL_UART_Receive_IT(&huart3, (uint8_t*)&g_keypad_uart_byte, 1) != HAL_OK) {
        OLED_operate_gram(PEN_CLEAR);
        OLED_show_string(0, 2, (uint8_t *)"ERROR: Keypad UART");
        OLED_refresh_gram();
        g_app_state = STATE_IDLE;
        return;
    }
    
    Update_Display(); // 在OLED上显示主菜单
}
void Analyze_Filter_Response(void) {
    float max_gain = 0.0f;
    int max_gain_index = 0;
    float min_gain = 1e9; // 初始化为一个很大的数
    int min_gain_index = 0;

    // 步骤 1: 找到最大和最小增益及其位置
    for (int i = 0; i < NUM_SWEEP_STEPS; i++) {
        if (g_H_magnitude[i] > max_gain) {
            max_gain = g_H_magnitude[i];
            max_gain_index = i;
        }
        if (g_H_magnitude[i] < min_gain) {
            min_gain = g_H_magnitude[i];
            min_gain_index = i;
        }
    }

    // 紧急情况处理：如果几乎没有信号，默认猜测为低通
    if (max_gain < 0.05f) {
        g_filter_type = FILTER_TYPE_LOW_PASS;
        return;
    }
 // 步骤 2: 定义关键的增益和相位阈值
    float cutoff_gain = max_gain * 0.707f;
    float start_gain = g_H_magnitude[0];
    float end_gain = g_H_magnitude[NUM_SWEEP_STEPS - 1];
    
    // 获取关键点的相位 (弧度)
    float start_phase = g_H_phase[0];
    float end_phase = g_H_phase[NUM_SWEEP_STEPS - 1];
    float phase_at_max_gain = g_H_phase[max_gain_index];
    
    // 定义相位判断的容差 (例如 PI/8 约等于 22.5度)
    const float PHASE_TOLERANCE = M_PI / 8.0f;

    // --- 阶段1：根据幅度谱进行粗判 ---

    // 1a. 判断为“带阻型” (起始和结尾增益都高)
    if (start_gain > cutoff_gain && end_gain > cutoff_gain && min_gain < max_gain * 0.5f) {
        g_filter_type = FILTER_TYPE_BAND_STOP;
        return; // 最终判断
    }
    
    // 1b. 判断为“低通型” (起始增益高, 结尾增益低)
    else if (start_gain > cutoff_gain && end_gain < cutoff_gain) {
        g_filter_type = FILTER_TYPE_LOW_PASS;
        return; // 最终判断
    }

    // 1c. 判断为“高通/带通混合型” (起始增益低)
    else if (start_gain < cutoff_gain) {
        
    //  带通滤波器 (Band-Pass)
    // 幅度假设: 起始和结尾增益都低
    if (start_gain < cutoff_gain && end_gain < cutoff_gain) {
        // 相位验证: 在最大增益点(中心频率)处，相位应该接近0度
        if (fabsf(phase_at_max_gain) < PHASE_TOLERANCE) {
            g_filter_type = FILTER_TYPE_BAND_PASS;
            return;
        }
    }
		// 高通滤波器 (High-Pass)
    // 幅度假设: 起始增益低，结尾增益高
    if (start_gain < cutoff_gain && end_gain > cutoff_gain) {
        // 相位验证: 相位应该从+180度( +PI )附近开始，到0度附近结束
        // 注意：相位可能被卷绕在-PI，所以检查绝对值
        if (fabsf(end_phase) < PHASE_TOLERANCE) {
            g_filter_type = FILTER_TYPE_HIGH_PASS;
            return;
        }
     }
		    //  带通滤波器 (Band-Pass)
    // 幅度假设: 起始和结尾增益都低
    if (start_gain < cutoff_gain && end_gain < cutoff_gain) {
            g_filter_type = FILTER_TYPE_BAND_PASS;
            return;
    }
		// 高通滤波器 (High-Pass)
    // 幅度假设: 起始增益低，结尾增益高
    if (start_gain < cutoff_gain && end_gain > cutoff_gain) {
            g_filter_type = FILTER_TYPE_HIGH_PASS;
            return;
     }
    }
    // 规则 5: 【最终裁决】如果以上严格规则都不满足，则使用更宽松的规则做最佳猜测
    // 这种情况下，主要依靠整体的相位变化趋势，因为它比幅度趋势更可靠
    float total_phase_shift = end_phase - start_phase;
    
    if (total_phase_shift < -M_PI * 0.8f) { // 总相移接近-180度 -> 低通特征
        g_filter_type = FILTER_TYPE_LOW_PASS;
    } else if (total_phase_shift > M_PI * 0.8f) { // 总相移接近+180度 -> 高通特征
        g_filter_type = FILTER_TYPE_HIGH_PASS;
    } else if (fabsf(phase_at_max_gain) < M_PI / 4.0f && max_gain_index > NUM_SWEEP_STEPS * 0.1 && max_gain_index < NUM_SWEEP_STEPS * 0.9) {
        // 峰值在中间，且峰值处相位不算太偏 -> 带通特征
        g_filter_type = FILTER_TYPE_BAND_PASS;
    } else {
        // 如果相位特征也很模糊，则退回使用幅度的峰值位置做最终猜测
        if (max_gain_index < NUM_SWEEP_STEPS / 2) {
            g_filter_type = FILTER_TYPE_LOW_PASS;
        } else {
            g_filter_type = FILTER_TYPE_HIGH_PASS;
        }
    }
    
}
void Stop_Simulation_Mode(void) {
    HAL_TIM_IC_Stop_DMA(&htim4, TIM_CHANNEL_2); 
    HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
    HAL_ADC_Stop_DMA(&hadc2);
    g_app_state = STATE_IDLE;
    OLED_operate_gram(PEN_CLEAR);
    OLED_show_string(0, 0, (uint8_t *)"System Ready.");
    OLED_show_string(0, 2, (uint8_t *)"Press a key...");
    OLED_refresh_gram();
}
void Start_Simulation_Mode(void) {
    HAL_GPIO_WritePin(RELAY_GPIO_Port, RELAY_Pin, RELAY_STATE_SIMULATE);
    HAL_Delay(20);
    OLED_operate_gram(PEN_CLEAR);
    OLED_show_string(0, 2, (uint8_t *)"Simulation Active");
    OLED_show_string(0, 4, (uint8_t *)"Press Learn to Stop");
    OLED_refresh_gram();

    if (HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1, (uint32_t*)g_dac_output_buffer, ADC_TOTAL_BUFFER_SIZE, DAC_ALIGN_12B_R) != HAL_OK) Error_Handler();
    if (HAL_ADC_Start_DMA(&hadc2, (uint32_t*)g_adc2_dma_buffer, ADC_TOTAL_BUFFER_SIZE) != HAL_OK) Error_Handler();
    // *** 使用DMA方式启动输入捕获 ***
    if (HAL_TIM_IC_Start_DMA(&htim4, TIM_CHANNEL_2, (uint32_t*)g_tim_capture_buffer, CAPTURE_BUFFER_SIZE) != HAL_OK)
    {
        Error_Handler();
    }
    g_current_sampling_simulation = 200000.0f;
    Write_frequence(3, g_current_sampling_simulation);
    Write_Amplitude(3, 1023);
    g_app_state = STATE_SIMULATING;
}

/**
 * @brief  处理DMA捕获到的时间戳缓冲区，计算平均频率
 * @param  buffer: 指向包含时间戳数据的缓冲区
 * @param  len:    要处理的数据长度
 * @retval None
 */
void Process_Capture_Buffer(volatile uint32_t* buffer, uint16_t len)
{
    uint64_t total_ticks = 0;
    uint32_t valid_periods = 0;
    
    for (int i = 0; i < len - 1; i++)
    {
        uint32_t tick_diff;
        // 处理定时器溢出（假设TIM4是16位定时器）
        if (buffer[i+1] > buffer[i])
        {
            tick_diff = buffer[i+1] - buffer[i];
        }
        else
        {
            // 0xFFFF 是16位定时器的最大值, 如果你的定时器是32位的，请使用 0xFFFFFFFF
            tick_diff = (0xFFFF - buffer[i]) + buffer[i+1] + 1; 
        }      
        total_ticks += tick_diff;
        valid_periods++;
    }
    if (valid_periods > 0)
    {
        // 计算单个周期的平均tick数
        float avg_period_ticks = (float)total_ticks / valid_periods;
        // 计算频率
        g_measured_freq = TIMER4_TICK_FREQ_HZ / avg_period_ticks;
    }
}
/**
 * @brief  ?????????
 */
void Start_Sweep_And_Analysis(void) {
	  g_sweep_current_step = 0;
    g_current_freq_sweep = SWEEP_START_FREQ_HZ;
    g_filter_type = FILTER_TYPE_UNKNOWN;
	  Write_frequence(0, g_current_freq_sweep);
		Write_Amplitude(0, 1000);
		HAL_GPIO_WritePin(RELAY_GPIO_Port, RELAY_Pin, RELAY_STATE_LEARN);
	  if (HAL_ADC_Start_DMA(&hadc1, (uint32_t*)g_adc1_dma_buffer, ADC_TOTAL_BUFFER_SIZE) != HAL_OK) {
       Error_Handler();
     }
    if (HAL_ADC_Start_DMA(&hadc2, (uint32_t*)g_adc2_dma_buffer, ADC_TOTAL_BUFFER_SIZE) != HAL_OK) {
       Error_Handler();
     }
	  sampling_frequency_sweep=g_current_freq_sweep*20;
	  stable_flag=0;
	  Write_frequence(3, sampling_frequency_sweep);
		Write_Amplitude(3, 1000);
		g_adc1_data_ready = 0;
    g_adc2_data_ready = 0;
	  HAL_Delay(SETTLE_TIME_MS); 
    OLED_operate_gram(PEN_CLEAR);
    OLED_show_string(0, 2, (uint8_t *)"Learning...");
    OLED_refresh_gram();
    g_adc1_data_ready = 0;
    g_adc2_data_ready = 0;
    
    g_app_state = STATE_SWEEPING;
}


/**
 * @brief  Calculates the precise amplitude and phase of a single sine wave using a single-frequency DFT.
 *
 * @param  processing_buffer      Pointer to the buffer containing ADC sample values (uint16_t).
 * @param  target_frequency_hz    The frequency of the target signal (Hz).
 * @param  current_sampling_freq_hz The actual sampling frequency used to acquire this buffer (Hz).
 * @param  p_amplitude_v          Pointer to a float to store the calculated amplitude (in Volts).
 * @param  p_phase_rad            Pointer to a float to store the calculated phase (in radians).
 */
void Get_Signal_Accurate_Amplitude_And_Phase(const uint16_t* processing_buffer,
                                             float target_frequency_hz,
                                             float current_sampling_freq_hz,
                                             float* p_amplitude_v,
                                             float* p_phase_rad)
{
    // --------------------------------------------------------------------------
    // 1. Preparation: Calculate parameters needed for DFT
    // --------------------------------------------------------------------------

    // DFT bin formula: f_k = k * fs / N  =>  k = f_k * N / fs
    // Use the passed-in current sampling frequency for an accurate calculation.
    const float k = target_frequency_hz * (float)NUM_SAMPLES / current_sampling_freq_hz;

    // Calculate angular frequency w = 2 * PI * k / N
    const float w = 2.0f * M_PI * k / (float)NUM_SAMPLES;

    float real_dc_offset = 0.0f;
    for (int i = 0; i < NUM_SAMPLES; i++) {
        real_dc_offset += (float)processing_buffer[i];
    }
    real_dc_offset /= (float)NUM_SAMPLES;

    // Initialize the sum for the real and imaginary parts of the DFT
    float sum_real = 0.0f;
    float sum_imag = 0.0f;

    // --------------------------------------------------------------------------
    // 2. Core Calculation: Execute the single-frequency DFT
    // --------------------------------------------------------------------------

    for (int n = 0; n < NUM_SAMPLES; n++)
    {
        float sample_no_dc = (float)processing_buffer[n] - real_dc_offset;
        float angle = w * (float)n;
        sum_real += sample_no_dc * arm_cos_f32(angle);
        sum_imag += sample_no_dc * arm_sin_f32(angle);
    }

    // --------------------------------------------------------------------------
    // 3. Post-processing: Calculate amplitude and phase from DFT results
    // --------------------------------------------------------------------------
    float dft_real = sum_real;
    float dft_imag = -sum_imag;

    // 计算幅度
   float magnitude_squared = dft_real * dft_real + dft_imag * dft_imag;
    float magnitude = 0.0f;
    arm_sqrt_f32(magnitude_squared, &magnitude); // 正确的用法

     float amplitude_adc_units = (2.0f / (float)NUM_SAMPLES) * magnitude;
    *p_amplitude_v = amplitude_adc_units * (ADC_VREF_V / (float)ADC_RESOLUTION);
		*p_phase_rad = atan2f(dft_imag, dft_real);
}
void Display_Results(void) {
    OLED_operate_gram(PEN_CLEAR);
    OLED_show_string(0, 0, (uint8_t *)"Analysis Complete!");
    char* type_str = "Type: Unknown";
    switch (g_filter_type) {
        case FILTER_TYPE_LOW_PASS:  type_str = "Type: Low-Pass";  break;
        case FILTER_TYPE_HIGH_PASS: type_str = "Type: High-Pass"; break;
        case FILTER_TYPE_BAND_PASS: type_str = "Type: Band-Pass"; break;
        case FILTER_TYPE_BAND_STOP: type_str = "Type: Band-Stop"; break;
        default: break;
    }
    OLED_show_string(2, 0, (uint8_t *)type_str);
    OLED_show_string(4, 0, (uint8_t *)"Press SIM key");
    OLED_refresh_gram();
}
/**
  * @brief  ADC DMA ����һ����ɻص�������
  */
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc) {
    if (hadc->Instance == ADC1) {
        if(g_app_state == STATE_SWEEPING) {
					if(stable_flag==0){
						 stable_flag=1;
					}else if (stable_flag==1){
					   stable_flag=2;
					}
            memcpy(g_adc1_processing_buffer, (const void*)&g_adc1_dma_buffer[0], ADC_SAMPLES_PER_HALF_BUFFER * sizeof(uint16_t));
            g_adc1_data_ready = 1;
        }
    }
    else if (hadc->Instance == ADC2) {
        if (g_app_state == STATE_SWEEPING) {
            memcpy(g_adc2_processing_buffer, (const void*)&g_adc2_dma_buffer[0], ADC_SAMPLES_PER_HALF_BUFFER * sizeof(uint16_t));
            g_adc2_data_ready = 1;
        }
        else if (g_app_state == STATE_SIMULATING) {
					memcpy(g_adc2_processing_buffer, (const void*)&g_adc2_dma_buffer[0], ADC_SAMPLES_PER_HALF_BUFFER * sizeof(uint16_t));
            dac_half_flag=1;
            
        }
    }
}

/**
  * @brief  ADC DMA ������ɻص�������
  */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
    if (hadc->Instance == ADC1) {
        if(g_app_state == STATE_SWEEPING) {
            memcpy(g_adc1_processing_buffer, (const void*)&g_adc1_dma_buffer[ADC_SAMPLES_PER_HALF_BUFFER], ADC_SAMPLES_PER_HALF_BUFFER * sizeof(uint16_t));
            g_adc1_data_ready = 1;
        }
    }
    else if (hadc->Instance == ADC2) {
        if (g_app_state == STATE_SWEEPING) {
            memcpy(g_adc2_processing_buffer, (const void*)&g_adc2_dma_buffer[ADC_SAMPLES_PER_HALF_BUFFER], ADC_SAMPLES_PER_HALF_BUFFER * sizeof(uint16_t));
            g_adc2_data_ready = 1;
        }
        else if (g_app_state == STATE_SIMULATING) {
					memcpy(g_adc2_processing_buffer, (const void*)&g_adc2_dma_buffer[ADC_SAMPLES_PER_HALF_BUFFER], ADC_SAMPLES_PER_HALF_BUFFER * sizeof(uint16_t));
           dac_full_flag=1;
           
        }
    }
}
/**
  * @brief  在仿真模式下，使用DFT处理ADC数据并生成DAC输出。
  * @note   此函数计算输入信号的基波及最多10次谐波的幅度和相位。
  * 然后，它会查找在学习模式下测得的H(w)值，对每个谐波分量进行滤波。
  * 最后，通过反向DFT（合成）重建时域信号并写入DAC缓冲区。
  * @param  adc_src             指向源ADC数据缓冲区的指针 (大小为 ADC_SAMPLES_PER_HALF_BUFFER)。
  * @param  dac_dest            指向目标DAC数据缓冲区的指针 (大小为 ADC_SAMPLES_PER_HALF_BUFFER)。
  * @param  signal_base_freq_hz 输入信号的基频 (Hz)。
  * @param  sampling_freq_hz    当前的采样频率 (Hz)。
  */
void Process_Buffer_DFT_SIM(const uint16_t* adc_src,
                           volatile uint16_t* dac_dest,
                           float signal_base_freq_hz,
                           float sampling_freq_hz)
{
    // --- 常量与缓冲区定义 ---
    const int NUM_HARMONICS = 9; 
    const int NUM_COMPONENTS = NUM_HARMONICS + 1; // 基波 + 9谐波
    const int BUFFER_SIZE = ADC_SAMPLES_PER_HALF_BUFFER;

    // 存储每个谐波分量的幅度和相位
    float mag_X_V[NUM_COMPONENTS];      // 输入信号 X(w) 的幅度 (伏特)
    float phase_X_rad[NUM_COMPONENTS];  // 输入信号 X(w) 的相位 (弧度)
    float mag_Y_V[NUM_COMPONENTS];      // 输出信号 Y(w) 的幅度 (伏特)
    float phase_Y_rad[NUM_COMPONENTS];  // 输出信号 Y(w) 的相位 (弧度)

    // --- 步骤 1: 计算输入信号的直流偏置 ---
    float dc_offset_adc = 0.0f;
    for (int i = 0; i < BUFFER_SIZE; i++) {
        dc_offset_adc += (float)adc_src[i];
    }
    dc_offset_adc /= (float)BUFFER_SIZE;

    // --- 步骤 2: 对每个谐波分量进行前向DFT, 并应用滤波器H(w) ---
    for (int h = 0; h < NUM_COMPONENTS; h++) {
        // 当前处理的频率 (h=0是基波, h=1是2次谐波, ...)
        float current_freq_hz = signal_base_freq_hz * (float)(h + 1);

        // --- 2a. 对当前频率执行单频DFT ---
        const float k = current_freq_hz * (float)BUFFER_SIZE / sampling_freq_hz;
        const float w = 2.0f * M_PI * k / (float)BUFFER_SIZE;
        float sum_real = 0.0f;
        float sum_imag = 0.0f;

        for (int n = 0; n < BUFFER_SIZE; n++) {
            float sample_no_dc = (float)adc_src[n] - dc_offset_adc;
            float angle = w * (float)n;
            sum_real += sample_no_dc * arm_cos_f32(angle);
            sum_imag += sample_no_dc * arm_sin_f32(angle);
        }

        float dft_real = sum_real;
        float dft_imag = -sum_imag; // 根据DFT定义调整符号
        float magnitude_squared = dft_real * dft_real + dft_imag * dft_imag;
        // 计算输入信号X(w)的幅度和相位
				float magnitude = 0.0f;
        arm_sqrt_f32(magnitude_squared, &magnitude); // 正确的用法
        float amplitude_adc_units = (2.0f / (float)BUFFER_SIZE) * magnitude;
        mag_X_V[h] = amplitude_adc_units * (ADC_VREF_V / (float)ADC_RESOLUTION);
        phase_X_rad[h] = atan2f(dft_imag, dft_real);

        // --- 2b. 查找对应的滤波器响应H(w) ---
        float mag_H = 0.0f;   // 默认增益为0
        float phase_H = 0.0f; // 默认相移为0

        // 检查频率是否在扫描范围内
        if (current_freq_hz >= SWEEP_START_FREQ_HZ && current_freq_hz <= SWEEP_END_FREQ_HZ) {
            // 计算索引，找到最接近的频率点
            int h_idx = roundf((current_freq_hz - SWEEP_START_FREQ_HZ) / SWEEP_STEP_FREQ_HZ);
            if (h_idx >= 0 && h_idx < NUM_SWEEP_STEPS) {
                mag_H = g_H_magnitude[h_idx];
                phase_H = g_H_phase[h_idx];
            }
        }
        // 如果频率超出范围, mag_H将保持为0, 从而滤除该谐波

        // --- 2c. 计算输出 Y(w) = H(w) * X(w) ---
        mag_Y_V[h] = mag_X_V[h] * mag_H;
        phase_Y_rad[h] = phase_X_rad[h] + phase_H;
    }
		
    // --- 步骤 3: 反向DFT (信号重建) ---
    const float dc_out_dac = (float)DAC_RESOLUTION / 2.0f; // 正确：使用DAC的宏

    for (int n = 0; n < BUFFER_SIZE; n++) {
        float sample_value_dac = dc_out_dac; // 从直流偏置开始

        // 叠加所有谐波分量来重建信号
        for (int h = 0; h < NUM_COMPONENTS; h++) {
            float current_freq_hz = signal_base_freq_hz * (float)(h + 1);
            // 将输出幅度从伏特转换回DAC单位
            float amp_Y_dac = mag_Y_V[h] * ((float)DAC_RESOLUTION / ADC_VREF_V); // 正确：使用DAC的宏

            sample_value_dac += amp_Y_dac * arm_cos_f32(2.0f * M_PI * current_freq_hz * (float)n / sampling_freq_hz + phase_Y_rad[h]);
        }

        // --- 步骤 4: 限幅并存入DAC缓冲区 ---
        if (sample_value_dac < 0.0f) {
            sample_value_dac = 0.0f;
        } else if (sample_value_dac > (DAC_RESOLUTION - 1.0f)) { // 正确：使用DAC的宏
             sample_value_dac = (DAC_RESOLUTION - 1.0f);
        }
        dac_dest[n] = (uint16_t)sample_value_dac;
    }
}
void HAL_TIM_IC_CaptureHalfCpltCallback(TIM_HandleTypeDef *htim) {
  // 半传输完成（可选）
	memcpy(g_calc_half_buffer ,(const void*)&g_tim_capture_buffer[0], sizeof(g_calc_half_buffer));
	g_capture_buffer_full_ready=0;
    g_capture_buffer_half_ready = 1;
}
// DMA传输完成回调
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim) {

	memcpy(g_calc_full_buffer, (const void*)&g_tim_capture_buffer[CAPTURE_BUFFER_SIZE / 2], sizeof(g_calc_full_buffer));
	g_capture_buffer_half_ready=0;
	g_capture_buffer_full_ready = 1;
}

/**
 * @brief Calculates the magnitude of the known transfer function H(s).
 * @note  The transfer function from the spec is H(s) = 1 / (10^-8*s^2 + 3e-4*s + 1).
 */
double Calculate_H_Magnitude(double freq_hz) {
    double omega = 2.0 * M_PI * freq_hz;
    double real_part = 1.0 - 1e-8 * omega * omega;
    double imag_part = 3e-4 * omega;
    double denominator_magnitude = sqrt(real_part * real_part + imag_part * imag_part);
    
    if (denominator_magnitude == 0) return 0;
    return 5.0 / denominator_magnitude;
}


/**
 * @brief Processes a complete keypad command if one is ready.
 */
void Process_Keypad_Input(void) {
    if (!g_keypad_data_ready) return;
       g_keypad_data_ready = 0; // Reset flag after processing

    if (g_keypad_rx_buffer[0] == KEYPAD_FRAME_HEAD && g_keypad_rx_buffer[2] == KEYPAD_FRAME_TAIL) {
        uint8_t key_code = g_keypad_rx_buffer[1];
        Handle_Menu_Navigation(key_code);
    }
}
/**
 * @brief  在不改变运行状态的情况下，立即用当前参数更新DDS输出。
 */
void Update_DDS_Output(void)
{
    // 检查是否处于运行状态，只有运行时才更新
    if (g_basic_mode_active)
    {
        Calculate_Required_Output(); // 直接调用计算和输出函数
    }
}
/**
 * @brief  根据按键输入处理菜单导航和用户反馈。
 * @note   最终版：使用正确的按键码，并在设置成功后立即更新DDS输出。
 */
void Handle_Menu_Navigation(uint8_t key)
{

    switch (g_menu_state)
    {
        case MENU_MAIN:
            if (key == 0x01) {
                g_menu_state = MENU_SET_FREQ;
                g_input_index = 0;
                memset(g_input_buffer, 0, sizeof(g_input_buffer));
            } else if (key == 0x02) {
                g_menu_state = MENU_SET_OUTPUT;
                g_input_index = 0;
                memset(g_input_buffer, 0, sizeof(g_input_buffer));
            } else if (key == 0x03) {
                Start_Basic_Mode();
            } else if (key == 0x04) {
                if(g_basic_mode_active) {
                    Stop_Basic_Mode();
                } else {
                    HAL_UART_AbortReceive_IT(&huart3);
                    g_app_state = STATE_IDLE;
                    OLED_operate_gram(PEN_CLEAR);
                    OLED_show_string(0, 0, (uint8_t *)"--- STATUS ---");
                    OLED_show_string(2, 0, (uint8_t *)"Mode: IDLE");
                    OLED_refresh_gram();
                    return; 
                }
            }else if (key == 0x05) { 
                if (g_basic_amp_mode == AMP_MODE_MODEL_OUTPUT) {
                    g_basic_amp_mode = AMP_MODE_DIRECT;
                } else {
                    g_basic_amp_mode = AMP_MODE_MODEL_OUTPUT;
                }
            }
            break;

        case MENU_SET_FREQ:
        case MENU_SET_OUTPUT:
            // 使用你定义的 KEY_CONFIRM (0x10)
            if (key == KEY_CONFIRM) {
                if (g_input_index > 0) {
                    uint32_t value = atoi(g_input_buffer);
                    uint8_t is_valid = 0;

                    if (g_menu_state == MENU_SET_FREQ) {
                        // 根据题目要求(2)放宽频率范围
                        if (value >= 1 && value <= 3000000) {
                            g_target_freq_hz = value;
                            is_valid = 1;
                        }
                    } else { // MENU_SET_OUTPUT
                        if (value >= 1 && value <= 5000) { // 题目要求峰峰值不小于3V，这里假设可设范围为1-3V
                            g_target_output_mv = value;
                            is_valid = 1;
                        }
                    }

                    if (is_valid) {
                        OLED_operate_gram(PEN_CLEAR);
                        OLED_show_string(0, 2, (uint8_t *)"Set Success!");
                        OLED_refresh_gram();
                        HAL_Delay(1000);
                        
                        // 核心逻辑：如果已在运行，则立即更新输出
                        Update_DDS_Output(); 
                        
                        g_menu_state = MENU_MAIN;
                    } else {
                        OLED_operate_gram(PEN_CLEAR);
                        OLED_show_string(0, 2, (uint8_t *)"Error: Out of Range!");
                        OLED_refresh_gram();
                        HAL_Delay(1500);
                        g_input_index = 0;
                        memset(g_input_buffer, 0, sizeof(g_input_buffer));
                    }
                } else {
                    g_menu_state = MENU_MAIN;
                }
            } else if (key >= 0x01 && key <= 0x09) {
                if (g_input_index < KEYPAD_BUFFER_SIZE - 1) g_input_buffer[g_input_index++] = '0' + key;
            } else if (key == KEY_ZERO) { // 使用你定义的 KEY_ZERO (0x0A)
                if (g_input_index < KEYPAD_BUFFER_SIZE - 1) g_input_buffer[g_input_index++] = '0';
            } else if (key == KEY_BACKSPACE) {
                if (g_input_index > 0) {
                    g_input_index--;
                    g_input_buffer[g_input_index] = '\0';
                }
            }
            break;

        case MENU_RUNNING:
            if (key == 0x04) {
                Stop_Basic_Mode();
            } else if (key == 0x01 || key == 0x02) {
                g_menu_state = (key == 0x01) ? MENU_SET_FREQ : MENU_SET_OUTPUT;
                g_input_index = 0;
                memset(g_input_buffer, 0, sizeof(g_input_buffer));
            }
            break;
    }
    Update_Display();
}
/**
 * @brief  根据当前菜单状态更新OLED显示内容。
 * @note   已修正，优化了显示布局，确保内容清晰不越界。
 */
void Update_Display(void) {
    OLED_operate_gram(PEN_CLEAR);
    
    switch (g_menu_state) {
        case MENU_MAIN:
					  OLED_operate_gram(PEN_CLEAR);
            OLED_show_string(0, 0, (uint8_t *)"--- Basic Mode ---");
            OLED_printf(2, 0, "1:Set Freq  2:Set V");
            OLED_printf(3, 0, "3:START     4:STOP/EXIT");
            const char* mode_str = (g_basic_amp_mode == AMP_MODE_DIRECT) ? "Direct" : "Model";
            OLED_printf(4, 0, "5:Mode(%s)", mode_str);
            OLED_printf(5, 0, "F_set: %luHz", g_target_freq_hz);
            OLED_printf(6, 0, "V_set: %lumV", g_target_output_mv);
				    if (g_basic_amp_mode == AMP_MODE_DIRECT) {
                 OLED_printf(7, 0, "DDS Vpp: %lumV", g_target_output_mv);
            } else { // AMP_MODE_MODEL_OUTPUT
                 OLED_printf(7, 0, "Model Vout: %lumV", g_target_output_mv);
            }
            OLED_show_string(8, 0, (uint8_t *)(g_basic_mode_active ? "Status: RUNNING" : "Status: STOPPED"));
	          OLED_refresh_gram();
            break;
            
        case MENU_SET_FREQ:
					  OLED_operate_gram(PEN_CLEAR);
            OLED_show_string(0, 0, (uint8_t *)"--- Set Freq ---");
            OLED_show_string(2, 0, (uint8_t *)"Range: 10-10000000 Hz");
            OLED_printf(4, 0, "Input: %s", g_input_buffer);
            OLED_show_string(6, 0, (uint8_t *)"Enter nums, '*' to save");
				    OLED_refresh_gram();
            break;
        case MENU_SET_OUTPUT:
					  OLED_operate_gram(PEN_CLEAR);
            if (g_basic_amp_mode == AMP_MODE_DIRECT) {
                OLED_show_string(0, 0, (uint8_t *)"--- Set DDS Vpp ---");
                OLED_show_string(2, 0, (uint8_t *)"Range: 1-5000 mV"); // 假设DDS最大输出3Vpp
            } else { // AMP_MODE_MODEL_OUTPUT
                OLED_show_string(0, 0, (uint8_t *)"--- Set Model Vout ---");
                OLED_show_string(2, 0, (uint8_t *)"Range: 1-5000 mV"); // 您原来的范围
            }
            OLED_printf(4, 0, "Input: %s", g_input_buffer);
            OLED_show_string(6, 0, (uint8_t *)"Enter nums, '*' to save");
				    OLED_refresh_gram();
            break;
        case MENU_RUNNING:
					  OLED_operate_gram(PEN_CLEAR);
            OLED_show_string(0, 0, (uint8_t *)"** System RUNNING **");
            OLED_printf(3, 0, "Freq: %luHz", g_target_freq_hz);
            OLED_printf(4, 0, "Vout Target: %lumV", g_target_output_mv);
            OLED_show_string(7, 0, (uint8_t *)"Press (4) to STOP");
				    OLED_refresh_gram();
            break;
    }
    
    OLED_refresh_gram();
}


/**
 * @brief Starts the DDS signal generation for the basic mode.
 */
void Start_Basic_Mode(void) {
    if (!g_basic_mode_active) {
        g_basic_mode_active = 1;
        g_menu_state = MENU_RUNNING;
        Calculate_Required_Output();
        Update_Display();
    }
}

/**
 * @brief Stops the DDS signal generation for the basic mode.
 */
void Stop_Basic_Mode(void) {
    if (g_basic_mode_active) {
        g_basic_mode_active = 0;
        g_menu_state = MENU_MAIN;
        Write_Amplitude(0, 0); // Stop DDS output
        Update_Display();
    }
}


/**
 * @brief UART Receive Complete Callback.
 * @note  This function is called by the HAL driver whenever a byte is received via interrupt.
 * It implements a state machine to parse the 3-byte frame (0xFF, key_code, 0xEE)
 * from the serial matrix keypad.
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // A static state variable preserves the receiver's state between interrupts.
    static KeypadRxState rx_state = RX_STATE_WAIT_FOR_HEAD;
    // A static variable to temporarily store the key code from the frame.
    static uint8_t received_key_code;

    // Ensure the interrupt is coming from the correct UART peripheral (e.g., USART3 for the keypad)
    if (huart->Instance == USART3)
    {
        switch (rx_state)
        {
            // State 1: Waiting for the frame header (0xFF)
            case RX_STATE_WAIT_FOR_HEAD:
                if (g_keypad_uart_byte == KEYPAD_FRAME_HEAD) // Frame head detected
                {
                    // Correct header found, move to the next state to wait for the data byte.
                    rx_state = RX_STATE_WAIT_FOR_DATA;
                }
                break;

            // State 2: Waiting for the key code data byte
            case RX_STATE_WAIT_FOR_DATA:
                // The key codes are from 0x01 to 0x10.
                received_key_code = g_keypad_uart_byte;
                // Data byte received, move to the next state to wait for the frame tail.
                rx_state = RX_STATE_WAIT_FOR_TAIL;
                break;

            // State 3: Waiting for the frame tail (0xEE)
            case RX_STATE_WAIT_FOR_TAIL:
                if (g_keypad_uart_byte == KEYPAD_FRAME_TAIL) // Frame tail detected
                {
                    // --- Frame successfully received ---
                    // Copy the complete, validated frame into the global buffer.
                    g_keypad_rx_buffer[0] = KEYPAD_FRAME_HEAD;
                    g_keypad_rx_buffer[1] = received_key_code;
                    g_keypad_rx_buffer[2] = KEYPAD_FRAME_TAIL;

                    // Set the flag to notify the main loop that new data is ready for processing.
                    g_keypad_data_ready = 1;
                }
                // Reset the state machine to wait for a new frame header,
                // regardless of whether the tail was correct or not. This prevents getting stuck.
                rx_state = RX_STATE_WAIT_FOR_HEAD;
                break;
            
            default:
                // In case of an invalid state, reset to be safe.
                rx_state = RX_STATE_WAIT_FOR_HEAD;
                break;
        }

        // Re-arm the UART interrupt to receive the next byte.
        HAL_UART_Receive_IT(huart, (uint8_t*)&g_keypad_uart_byte, 1);
    }
}

/**
 * @brief Calculates the required DDS input amplitude based on target output and H(s).
 */
void Calculate_Required_Output(void) {
        uint32_t amp_setting = 0;

    // 根据选择的模式执行不同的计算逻辑
    if (g_basic_amp_mode == AMP_MODE_DIRECT) {
        /***** 模式1: 直接设置DDS输出 *****/
        // 将用户设置的目标mVpp直接转换为AD9959的幅度参数
        double target_vpp = (double)g_target_output_mv / 1000.0;
        amp_setting = (uint32_t)(target_vpp * DDS_VPP_TO_AMP_SCALE);

    } else { // g_basic_amp_mode == AMP_MODE_MODEL_OUTPUT
        /***** 模式2: 设置已知模型电路的输出 (您原来的逻辑) *****/
        double h_magnitude = Calculate_H_Magnitude((double)g_target_freq_hz);
        double required_input_vpp = 0.0;
        
        // 增加一个保护，防止h_magnitude过小导致计算结果溢出
        if (h_magnitude > 0.001) { 
            required_input_vpp = ((double)g_target_output_mv / 1000.0) / h_magnitude;
        }
        amp_setting = (uint32_t)(required_input_vpp * DDS_VPP_TO_AMP_SCALE);
    }

    // 对最终计算出的幅度值进行限幅，确保在有效范围内 (0-1023)
    if (amp_setting > 1023) {
        amp_setting = 1023;
    }
    // 如果用户设置了非零电压但计算结果为0，至少给一个最小输出
    if (amp_setting < 1 && g_target_output_mv > 0) {
        amp_setting = 1; 
    }

    // 将最终计算出的频率和幅度写入DDS
    Write_frequence(0, g_target_freq_hz);
    Write_Amplitude(0, amp_setting);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
